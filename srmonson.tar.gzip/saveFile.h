

#ifndef _SAVEFILE_H
#define _SAVEFILE_H
#include "image.h"
int save(image* arg, char* file);
#endif

