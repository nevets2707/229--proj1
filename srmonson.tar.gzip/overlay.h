#ifndef __OVERLAY_H_
#define __OVERLAY_H_
image* overlay(image* img1, image* img2, int x, int y);


#endif
